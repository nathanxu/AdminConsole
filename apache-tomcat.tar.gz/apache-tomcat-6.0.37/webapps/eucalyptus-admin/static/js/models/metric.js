// metric model

define([
    './eucamodel'
], function(EucaModel) {
    var model = EucaModel.extend({
    });
    return model;
});
