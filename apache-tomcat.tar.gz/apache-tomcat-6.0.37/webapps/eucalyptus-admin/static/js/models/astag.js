define(['./eucamodel'], function(EucaModel) {
  return EucaModel.extend({
    /* http://docs.aws.amazon.com/AutoScaling/latest/APIReference/API_TagDescription.html */

    sync: function(method) {
     
    }
  });
});
