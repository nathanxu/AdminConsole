define[], function() {
    return Backbone.view.extend({
        // accordion panels
        // image banners
        // image selection filters
        // paging
        // instance type selector
        //
        //
        // populate instance model with:
        // image
        // instance type
        // zone
        // security keys
        // security group
        //
    });
});
