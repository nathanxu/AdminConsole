/*************************************************************************
 * Copyright 2009-2012 Eucalyptus Systems, Inc.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/.
 *
 * Please contact Eucalyptus Systems, Inc., 6755 Hollister Ave., Goleta
 * CA 93117, USA or visit http://www.eucalyptus.com/licenses/ if you need
 * additional information or have any questions.
 ************************************************************************/

(function($, eucalyptus) {
  $.widget('eucalyptus.infrastructure_topology', $.eucalyptus.eucawidget, {
    options : { },
    cloudDetailDialog : null,
    clusterDetailDialog : null,
    nodeDetailDialog : null,
    _init : function() {
      thisObj = this;
      var $tmpl = $('html body div.templates').find('#infrastructureTopologyTmpl').clone();       
      var $wrapper = $($tmpl.render($.extend($.i18n.map, help_dashboard)));
      var $infrastructure = $wrapper.children().first();
      var $wrapper = $('<div>').addClass('infrastructure-wrapper');
      var cloudcontrollers = describe('infrastructure_clc');
      var clusters = describe('infrastructure_cc');
      var nodes = describe('infrastructure_node');
      $.each(cloudcontrollers, function(i, val) {
    	  if (i > 3) {
    		  return false;
    	  }
    	  $infrastructure.find('#cloud_item tr').append('<td><a href="#"><span class="topology-item-element">'+ val.name +'</span><br /><span class="topology-item-element">'+ val.hostName +'</span></a></td>');
      });
      $.each(clusters, function(i, val) {
    	  if (i > 3) {
    		  return false;
    	  }
    	  $infrastructure.find('#cluster_item tr').append('<td><a href="#"><span class="topology-item-element">'+ val.name +'</span><br /><span class="topology-item-element">'+ val.hostName +'</span></a></td>');
      });
      $.each(nodes, function(i, val) {
    	  if (i > 3) {
    		  return false;
    	  }
    	  $infrastructure.find('#node_item tr').append('<td><a href="#"><span class="topology-item-element">'+ val.partition +'</span><br /><span class="topology-item-element">'+ val.hostName +'</span></a></td>');
      });
      $infrastructure.appendTo($wrapper);
      $wrapper.appendTo(this.element);
      $wrapper.find('#cloud_item a').click(function(e){
    	  var name = $(this).children().first().html();
    	  cloudcomponent = describe('infrastructure_clc', name);
    	  thisObj.cloudDetailDialog.find('#name').html(cloudcomponent.name);
    	  thisObj.cloudDetailDialog.find('#hostname').html(cloudcomponent.hostName);
    	  thisObj.cloudDetailDialog.find('#fullname').html(cloudcomponent.fullName);
    	  thisObj.cloudDetailDialog.find('#type').html(cloudcomponent.type);
    	  thisObj.cloudDetailDialog.find('#detail').html(cloudcomponent.detail);
    	  thisObj.cloudDetailDialog.find('#status').html(cloudcomponent.state == 'enable' ? '<font color="green">'+ $.i18n.map.status_enable +'</font>':'<font color="red">'+ $.i18n.map.status_disable +'</font>');
    	  thisObj.cloudDetailDialog.eucadialog('open');
      });
      $wrapper.find('#walrus_item a').click(function(e){
          var name = $(this).children().first().html();
          cloudcomponent = describe('infrastructure_walrus', name);
          thisObj.cloudDetailDialog.find('#name').html(cloudcomponent.name);
          thisObj.cloudDetailDialog.find('#hostname').html(cloudcomponent.hostName);
          thisObj.cloudDetailDialog.find('#fullname').html(cloudcomponent.fullName);
          thisObj.cloudDetailDialog.find('#type').html(cloudcomponent.type);
          thisObj.cloudDetailDialog.find('#detail').html(cloudcomponent.detail);
          thisObj.cloudDetailDialog.find('#status').html(cloudcomponent.state == 'enable' ? '<font color="green">'+ $.i18n.map.status_enable +'</font>':'<font color="red">'+ $.i18n.map.status_disable +'</font>');
          thisObj.cloudDetailDialog.eucadialog('open');
      });
      $wrapper.find('#cluster_item a').click(function(e){
          var name = $(this).children().first().html();
          var cloudcomponent = describe('infrastructure_cc', name);
          thisObj.clusterDetailDialog.find('#name').html(cloudcomponent.name);
          thisObj.clusterDetailDialog.find('#hostname').html(cloudcomponent.hostName);
          thisObj.clusterDetailDialog.find('#fullname').html(cloudcomponent.fullName);
          thisObj.clusterDetailDialog.find('#type').html(cloudcomponent.type);
          thisObj.clusterDetailDialog.find('#partition').html(cloudcomponent.partition);
          thisObj.clusterDetailDialog.find('#detail').html(cloudcomponent.detail);
          thisObj.clusterDetailDialog.find('#status').html(cloudcomponent.state == 'enable' ? '<font color="green">'+ $.i18n.map.status_enable +'</font>':'<font color="red">'+ $.i18n.map.status_disable +'</font>');
          thisObj.clusterDetailDialog.eucadialog('open');
      });
      $wrapper.find('#node_item a').click(function(e){
          var partition = $(this).children().first().html();
          var cloudcomponent = describeByPartition('infrastructure_node', partition);
          thisObj.nodeDetailDialog.find('#hostname').html(cloudcomponent.hostName);
          thisObj.nodeDetailDialog.find('#fullname').html(cloudcomponent.fullName);
          thisObj.nodeDetailDialog.find('#type').html(cloudcomponent.type);
          thisObj.nodeDetailDialog.find('#partition').html(cloudcomponent.partition);
          thisObj.nodeDetailDialog.find('#detail').html(cloudcomponent.detail);
          thisObj.nodeDetailDialog.find('#status').html(cloudcomponent.state == 'enable' ? '<font color="green">'+ $.i18n.map.status_enable +'</font>':'<font color="red">'+ $.i18n.map.status_disable +'</font>');
          thisObj.nodeDetailDialog.eucadialog('open');
      });
    },

    _create : function() { 
        var $tmpl = $('html body div.templates').find('#cloudDetailDlgTmpl').clone();       
        var $rendered = $($tmpl.render($.extend($.i18n.map, help_dashboard)));
        var $cloud_detail_dialog = $rendered.children().first();
        var $cloud_detail_help = $rendered.children().last();
        this.cloudDetailDialog = $cloud_detail_dialog.eucadialog({
            id: 'cloud-detail',
            title: title_cloud,
            width: 400,
            buttons: {
              'cancel': {text: dialog_cancel_btn, focus:true, click: function() { $cloud_detail_dialog.eucadialog("close");}} 
            },
            help: { content: $cloud_detail_help, url: help_keypair.dialog_delete_content_url },
          });
        
        $tmpl = $('html body div.templates').find('#clusterDetailDlgTmpl').clone();       
        $rendered = $($tmpl.render($.extend($.i18n.map, help_dashboard)));
        var $cluster_detail_dialog = $rendered.children().first();
        var $cluster_detail_help = $rendered.children().last();
        this.clusterDetailDialog = $cluster_detail_dialog.eucadialog({
            id: 'cluster-detail',
            title: title_cluster,
            width: 400,
            buttons: {
              'cancel': {text: dialog_cancel_btn, focus:true, click: function() { $cluster_detail_dialog.eucadialog("close");}} 
            },
            help: { content: $cluster_detail_help, url: help_keypair.dialog_delete_content_url },
          });
        
        $tmpl = $('html body div.templates').find('#nodeDetailDlgTmpl').clone();       
        $rendered = $($tmpl.render($.extend($.i18n.map, help_dashboard)));
        var $node_detail_dialog = $rendered.children().first();
        var $node_detail_help = $rendered.children().last();
        this.nodeDetailDialog = $node_detail_dialog.eucadialog({
            id: 'node-detail',
            title: title_node,
            width: 400,
            buttons: {
              'cancel': {text: dialog_cancel_btn, focus:true, click: function() { $node_detail_dialog.eucadialog("close");}} 
            },
            help: { content: $node_detail_help, url: help_keypair.dialog_delete_content_url },
          });
    },
    
    _destroy : function() { },

    close: function() {
      this._super('close');
    }
  });
})(jQuery,
   window.eucalyptus ? window.eucalyptus : window.eucalyptus = {});
